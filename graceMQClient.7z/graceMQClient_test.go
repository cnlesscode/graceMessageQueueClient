package main

import (
	"encoding/json"
	"fmt"
	"testing"
	"time"

	"github.com/cnlesscode/graceMessageQueueClient/client"
)

// go test -v -run=TestInit
func TestInit(t *testing.T) {
	tcpConnectionPool, err := client.InitTCPConnetionPool("192.168.1.102:3001, 192.168.1.100:3001", 10)
	if err != nil {
		fmt.Printf("err: %v\n", err)
	} else {
		println("初始化成功")
	}
	for {
		// 发送消息
		message := client.Message{
			Type: 4,
		}
		messageByte, _ := json.Marshal(message)
		err = tcpConnectionPool.SendMessage(messageByte, func(data []byte) error {
			println("ooooo" + string(data))
			return nil
		})
		if err != nil {
			fmt.Printf("err: %v\n", err)
		}
		time.Sleep(time.Second)
	}
}
